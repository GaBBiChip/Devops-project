// ===== Загрузка standings =====
async function loadStandings() {
    const container = document.getElementById('standingsTable');
    container.innerHTML = '<div class="loading">Загрузка данных</div>';

    try {
        const response = await fetch('/api/standings');
        const standings = await response.json();

        let html = `
            <table class="standings-table">
                <thead>
                    <tr>
                        <th style="width: 80px;">#</th>
                        <th>Пилот</th>
                        <th>Команда</th>
                        <th style="width: 120px; text-align: right;">Очки</th>
                    </tr>
                </thead>
                <tbody>
        `;

        standings.forEach((pilot, index) => {
            const pos = index + 1;
            let badgeClass = '';
            if (pos === 1) badgeClass = 'position-1';
            else if (pos === 2) badgeClass = 'position-2';
            else if (pos === 3) badgeClass = 'position-3';

            html += `
                <tr>
                    <td>
                        <span class="position-badge ${badgeClass}">${pos}</span>
                    </td>
                    <td>
                        <div class="driver-cell">
                            <span class="driver-name-cell">${pilot.name}</span>
                        </div>
                    </td>
                    <td>
                        <span class="team-tag">${pilot.team}</span>
                    </td>
                    <td class="points-cell" style="text-align: right;">${pilot.points}</td>
                </tr>
            `;
        });

        html += '</tbody></table>';
        container.innerHTML = html;
    } catch (error) {
        container.innerHTML = `<div class="error">Ошибка загрузки: ${error.message}</div>`;
    }
}

// ===== Расчёт вероятности =====
async function calculateProbability() {
    const driverName = document.getElementById('driverName').value.trim();
    const resultBox = document.getElementById('probabilityResult');

    if (!driverName) {
        resultBox.innerHTML = '<div class="error">Введите имя пилота</div>';
        return;
    }

    resultBox.innerHTML = '<div class="loading">Вычисление</div>';

    try {
        const response = await fetch(`/api/probability?driver=${encodeURIComponent(driverName)}`);
        const data = await response.json();

        if (data.error) {
            resultBox.innerHTML = `<div class="error">${data.error}</div>`;
            return;
        }

        let status = '';
        let statusIcon = '';
        if (data.probability === 100) {
            status = 'Чемпион!';
            statusIcon = '🏆';
        } else if (data.probability === 0) {
            status = 'Математически невозможно';
            statusIcon = '❌';
        } else if (data.probability >= 50) {
            status = 'Фаворит';
            statusIcon = '🔥';
        } else if (data.probability >= 20) {
            status = 'В борьбе за титул';
            statusIcon = '⚡';
        } else {
            status = 'Шансы минимальны';
            statusIcon = '📉';
        }

        resultBox.innerHTML = `
            <div class="result-box">
                <div class="driver-name">${data.driver}</div>
                <div class="probability">${data.probability.toFixed(2)}%</div>
                <div class="status">${statusIcon} ${status}</div>
            </div>
        `;
    } catch (error) {
        resultBox.innerHTML = `<div class="error">Ошибка: ${error.message}</div>`;
    }
}

// ===== Загрузка результатов гонки =====
async function loadLastRace() {
    const container = document.getElementById('lastRaceResults');
    container.innerHTML = '<div class="loading">Загрузка данных</div>';

    try {
        const response = await fetch('/api/last-race');
        const data = await response.json();

        if (!data.success) {
            container.innerHTML = `<div class="error">Ошибка: ${data.error}</div>`;
            return;
        }

        const results = data.results;
        const metadata = results[0];
        const raceResults = results.slice(1);

        // Подиум (топ-3)
        const podium = raceResults.slice(0, 3);
        let podiumHtml = '<div class="podium">';
        const podiumClasses = ['first', 'second', 'third'];
        podium.forEach((r, i) => {
            podiumHtml += `
                <div class="podium-card ${podiumClasses[i]}">
                    <div class="podium-position">${i + 1}</div>
                    <div class="podium-driver">${r.driver}</div>
                    <div class="podium-team">${r.team}</div>
                </div>
            `;
        });
        podiumHtml += '</div>';

        // Остальные места
        let restHtml = `
            <table class="standings-table">
                <thead>
                    <tr>
                        <th style="width: 80px;">#</th>
                        <th>Пилот</th>
                        <th>Команда</th>
                    </tr>
                </thead>
                <tbody>
        `;
        raceResults.slice(3).forEach(r => {
            restHtml += `
                <tr>
                    <td><span class="position-badge">${r.position}</span></td>
                    <td><span class="driver-name-cell">${r.driver}</span></td>
                    <td><span class="team-tag">${r.team}</span></td>
                </tr>
            `;
        });
        restHtml += '</tbody></table>';

        container.innerHTML = `
            <div class="race-header">
                <div class="race-info-card">
                    <strong>Гран-при</strong>
                    <span>${metadata.raceName || 'Неизвестно'}</span>
                </div>
                <div class="race-info-card">
                    <strong>Место</strong>
                    <span>${metadata.location || 'Неизвестно'}</span>
                </div>
            </div>
            ${podiumHtml}
            ${restHtml}
        `;
    } catch (error) {
        container.innerHTML = `<div class="error">Ошибка загрузки: ${error.message}</div>`;
    }
}

// ===== Инициализация =====
document.addEventListener('DOMContentLoaded', () => {
    loadStandings();
    loadLastRace();

    // Автообновление каждые 30 секунд
    setInterval(() => {
        loadStandings();
        loadLastRace();
    }, 30000);

    // Enter для расчёта
    document.getElementById('driverName').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') calculateProbability();
    });
});