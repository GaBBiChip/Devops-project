package com.gabbichip.f1.service;

import com.gabbichip.f1.model.PilotStanding;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StandingsService {

    private final JdbcTemplate jdbcTemplate;
    private final CacheService cacheService;

    public StandingsService(JdbcTemplate jdbcTemplate, CacheService cacheService) {
        this.jdbcTemplate = jdbcTemplate;
        this.cacheService = cacheService;
    }

    public List<PilotStanding> getAllStandings() {
        List<PilotStanding> cached = cacheService.getStandingsCache();
        if (cached != null) return cached;

        List<PilotStanding> standings = jdbcTemplate.query(
                "SELECT id, name, points, number, team FROM standings ORDER BY points DESC",
                (rs, rowNum) -> new PilotStanding(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("points"),
                        rs.getString("number"),
                        rs.getString("team")
                )
        );

        cacheService.setStandingsCache(standings);
        return standings;
    }

    public double calculateProbability(String driverName) {
        Double cached = cacheService.getProbability(driverName);
        if (cached != null) return cached;

        List<PilotStanding> standings = getAllStandings();
        if (standings.isEmpty()) return 0.0;

        PilotStanding leader = standings.get(0);
        PilotStanding target = standings.stream()
                .filter(p -> p.getName().toLowerCase().contains(driverName.toLowerCase()))
                .findFirst()
                .orElse(null);

        if (target == null) return -1.0;

        int racesLeft = 2; // После Las Vegas: Qatar + Abu Dhabi
        int maxRemainingPoints = racesLeft * 26;
        int pointGap = leader.getPoints() - target.getPoints();

        double probability;
        if (pointGap <= 0) {
            probability = 100.0;
        } else if (pointGap <= maxRemainingPoints) {
            probability = (1.0 - ((double) pointGap / maxRemainingPoints)) * 100;
        } else {
            probability = 0.0;
        }

        cacheService.setProbability(driverName, probability);
        return probability;
    }
}