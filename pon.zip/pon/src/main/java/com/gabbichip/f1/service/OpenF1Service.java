package com.gabbichip.f1.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class OpenF1Service {

    @Value("${spring.datasource.url}")
    private String dbUrl;

    @Value("${spring.datasource.username}")
    private String dbUser;

    @Value("${spring.datasource.password}")
    private String dbPassword;

    private final CacheService cacheService;

    public OpenF1Service(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    private static final long REQUEST_DELAY_MS = 800;
    private static final long RETRY_DELAY_MS = 5000;
    private static final int MAX_RETRIES = 3;
    private static final int MAX_SCANNED_RACES = 16;

    // ===== Результаты последней гонки =====
    public List<Map<String, Object>> getLastRaceResults() throws Exception {
        // Проверяем кэш
        List<Map<String, Object>> cached = cacheService.getLastRaceCache();
        if (cached != null) return cached;

        String sessionsJson = fetch("https://api.openf1.org/v1/sessions?session_type=Race&session_key=latest");
        JsonArray sessions = JsonParser.parseString(sessionsJson).getAsJsonArray();
        if (sessions.isEmpty()) return List.of();

        JsonObject lastSession = sessions.get(0).getAsJsonObject();
        int sessionKey = lastSession.get("session_key").getAsInt();
        String location = safeString(lastSession, "location", "Unknown");
        String country = safeString(lastSession, "country_name", "");
        String raceName = location + (country.isEmpty() ? "" : ", " + country);

        String positionsJson = fetch("https://api.openf1.org/v1/position?session_key=" + sessionKey);
        JsonArray positions = JsonParser.parseString(positionsJson).getAsJsonArray();

        Map<Integer, Integer> finalPositions = new LinkedHashMap<>();
        for (JsonElement p : positions) {
            JsonObject pos = p.getAsJsonObject();
            if (!pos.has("driver_number") || !pos.has("position")) continue;
            finalPositions.put(pos.get("driver_number").getAsInt(), pos.get("position").getAsInt());
        }

        Map<Integer, JsonObject> driverMap = new HashMap<>();
        fillDriverMap(driverMap, sessionKey);

        List<Map<String, Object>> results = finalPositions.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .map(entry -> {
                    JsonObject d = driverMap.get(entry.getKey());
                    Map<String, Object> r = new HashMap<>();
                    r.put("position", entry.getValue());
                    r.put("driver", d != null ? safeString(d, "full_name", "Pilot #" + entry.getKey()) : "Pilot #" + entry.getKey());
                    r.put("team", d != null ? safeString(d, "team_name", "Unknown") : "Unknown");
                    return r;
                })
                .collect(Collectors.toList());

        Map<String, Object> metadata = new HashMap<>();
        metadata.put("raceName", raceName);
        metadata.put("location", location);
        metadata.put("sessionKey", sessionKey);
        results.add(0, metadata);

        // Сохраняем в кэш
        cacheService.setLastRaceCache(results);
        return results;
    }

    // ===== Полное обновление standings =====
    public void updateStandings() throws Exception {
        System.out.println("🔄 Начало обновления standings через OpenF1 API...");

        String standingsJson = fetch("https://api.openf1.org/v1/championship_drivers?session_key=latest");
        JsonArray standings = JsonParser.parseString(standingsJson).getAsJsonArray();
        if (standings.isEmpty()) {
            System.out.println("❌ championship_drivers пуст");
            return;
        }
        int sessionKey = standings.get(0).getAsJsonObject().get("session_key").getAsInt();
        System.out.println("✅ session_key актуальной гонки: " + sessionKey);

        Map<Integer, JsonObject> driverMap = new HashMap<>();
        fillDriverMap(driverMap, sessionKey);
        int year = resolveYear(sessionKey);

        Set<Integer> missing = new HashSet<>();
        for (JsonElement e : standings) {
            int num = e.getAsJsonObject().get("driver_number").getAsInt();
            if (!driverMap.containsKey(num)) missing.add(num);
        }

        if (!missing.isEmpty()) {
            System.out.println("Не хватает имён для " + missing.size() + " — ищу в первых гонках сезона " + year);
            JsonArray races = JsonParser.parseString(
                    fetch("https://api.openf1.org/v1/sessions?year=" + year + "&session_type=Race")).getAsJsonArray();
            int scanned = 0;
            for (int i = 0; i < races.size() && !missing.isEmpty() && scanned < MAX_SCANNED_RACES; i++) {
                JsonObject s = races.get(i).getAsJsonObject();
                if (!s.has("session_key")) continue;
                int sk = s.get("session_key").getAsInt();
                if (sk == sessionKey) continue;
                scanned++;
                try { fillDriverMap(driverMap, sk); } catch (Exception ex) {
                    System.out.println("⚠️  Пропущена сессия " + sk + ": " + ex.getMessage());
                }
                missing.removeIf(n -> driverMap.containsKey(n));
            }
        }

        List<String[]> rows = new ArrayList<>();
        for (JsonElement e : standings) {
            JsonObject st = e.getAsJsonObject();
            int num = st.get("driver_number").getAsInt();
            int points = (int) st.get("points_current").getAsDouble();
            JsonObject d = driverMap.get(num);
            String name = (d != null) ? safeString(d, "first_name", "?") + " " + safeString(d, "last_name", "") : "Pilot #" + num;
            String team = (d != null) ? safeString(d, "team_name", "Unknown") : "Unknown";
            rows.add(new String[]{name.trim(), String.valueOf(points), String.valueOf(num), team});
        }
        System.out.println(" Готово к записи: " + rows.size() + " пилотов");

        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            conn.setAutoCommit(false);
            try (PreparedStatement del = conn.prepareStatement("DELETE FROM standings");
                 PreparedStatement ins = conn.prepareStatement(
                         "INSERT INTO standings (name, points, number, team) VALUES (?, ?, ?, ?)")) {
                del.executeUpdate();
                for (String[] r : rows) {
                    ins.setString(1, r[0]);
                    ins.setInt(2, Integer.parseInt(r[1]));
                    ins.setString(3, r[2]);
                    ins.setString(4, r[3]);
                    ins.addBatch();
                }
                int[] done = ins.executeBatch();
                conn.commit();
                System.out.println("✅ Обновлено пилотов в БД: " + done.length);
            } catch (Exception ex) {
                conn.rollback();
                throw ex;
            }
        }

        // Очищаем кэш после обновления
        cacheService.clearAll();
    }

    // ===== Вспомогательные методы =====
    private void fillDriverMap(Map<Integer, JsonObject> map, int sessionKey) throws Exception {
        JsonArray drivers = JsonParser.parseString(
                fetch("https://api.openf1.org/v1/drivers?session_key=" + sessionKey)).getAsJsonArray();
        if (drivers == null) return;
        for (JsonElement e : drivers) {
            JsonObject d = e.getAsJsonObject();
            if (d.has("driver_number")) {
                map.putIfAbsent(d.get("driver_number").getAsInt(), d);
            }
        }
    }

    private int resolveYear(int sessionKey) throws Exception {
        JsonArray s = JsonParser.parseString(
                fetch("https://api.openf1.org/v1/sessions?session_key=" + sessionKey)).getAsJsonArray();
        if (!s.isEmpty() && s.get(0).getAsJsonObject().has("year")) {
            return s.get(0).getAsJsonObject().get("year").getAsInt();
        }
        return 2026;
    }

    private String safeString(JsonObject obj, String key, String fallback) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return fallback;
        return obj.get(key).getAsString();
    }

    private String fetch(String url) throws Exception {
        Thread.sleep(REQUEST_DELAY_MS);
        int attempt = 0;
        while (true) {
            attempt++;
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .timeout(Duration.ofSeconds(30))
                    .GET().build();
            HttpResponse<String> resp = HttpClient.newHttpClient()
                    .send(req, HttpResponse.BodyHandlers.ofString());
            int code = resp.statusCode();
            if (code == 200) return resp.body();
            if ((code == 429 || code >= 500) && attempt <= MAX_RETRIES) {
                System.out.println("⏳ HTTP " + code + " — жду и повторяю (" + attempt + "/" + MAX_RETRIES + ")");
                Thread.sleep(RETRY_DELAY_MS);
                continue;
            }
            throw new RuntimeException("HTTP " + code + " для URL: " + url);
        }
    }
}