package com.gabbichip.f1.service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CacheService {

    // Кэш standings (TTL 5 минут)
    private Object standingsCache;
    private long standingsLastUpdate = 0;
    private static final long STANDINGS_TTL_MS = 300_000;

    // Кэш вероятностей: имя пилота (lowercase) -> вероятность
    private final Map<String, Double> probabilityCache = new ConcurrentHashMap<>();

    // Кэш результатов последней гонки (TTL 10 минут)
    private Object lastRaceCache;
    private long lastRaceLastUpdate = 0;
    private static final long LAST_RACE_TTL_MS = 600_000;

    // ===== Standings =====
    @SuppressWarnings("unchecked")
    public <T> T getStandingsCache() {
        long now = System.currentTimeMillis();
        if (standingsCache != null && (now - standingsLastUpdate) < STANDINGS_TTL_MS) {
            System.out.println("Standings из кэша (остаток TTL: " + ((STANDINGS_TTL_MS - (now - standingsLastUpdate)) / 1000) + " сек)");
            return (T) standingsCache;
        }
        return null;
    }

    public void setStandingsCache(Object data) {
        this.standingsCache = data;
        this.standingsLastUpdate = System.currentTimeMillis();
        System.out.println("Standings сохранены в кэш");
    }

    // ===== Вероятности =====
    public Double getProbability(String driverName) {
        String cacheKey = driverName.toLowerCase().trim();
        if (probabilityCache.containsKey(cacheKey)) {
            System.out.println("Кэш вероятности: " + driverName + " = " + probabilityCache.get(cacheKey) + "%");
            return probabilityCache.get(cacheKey);
        }
        return null;
    }

    public void setProbability(String driverName, double probability) {
        String cacheKey = driverName.toLowerCase().trim();
        probabilityCache.put(cacheKey, probability);
        System.out.println("Вероятность закэширована: " + driverName + " = " + String.format("%.2f", probability) + "%");
    }

    // ===== Результаты последней гонки =====
    @SuppressWarnings("unchecked")
    public <T> T getLastRaceCache() {
        long now = System.currentTimeMillis();
        if (lastRaceCache != null && (now - lastRaceLastUpdate) < LAST_RACE_TTL_MS) {
            System.out.println("Результаты гонки из кэша");
            return (T) lastRaceCache;
        }
        return null;
    }

    public void setLastRaceCache(Object data) {
        this.lastRaceCache = data;
        this.lastRaceLastUpdate = System.currentTimeMillis();
        System.out.println("🏁 Результаты гонки сохранены в кэш");
    }

    // ===== Очистка всего кэша =====
    public void clearAll() {
        standingsCache = null;
        standingsLastUpdate = 0;
        probabilityCache.clear();
        lastRaceCache = null;
        lastRaceLastUpdate = 0;
        System.out.println("🗑️ Весь кэш очищен");
    }
}