package com.gabbichip.f1.controller;

import com.gabbichip.f1.model.PilotStanding;
import com.gabbichip.f1.service.StandingsService;
import com.gabbichip.f1.service.OpenF1Service;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class F1Controller {

    private final StandingsService standingsService;
    private final OpenF1Service openF1Service;

    public F1Controller(StandingsService standingsService, OpenF1Service openF1Service) {
        this.standingsService = standingsService;
        this.openF1Service = openF1Service;
    }

    @GetMapping("/standings")
    public List<PilotStanding> getStandings() {
        return standingsService.getAllStandings();
    }

    @GetMapping("/probability")
    public Map<String, Object> getProbability(@RequestParam String driver) {
        double probability = standingsService.calculateProbability(driver);
        Map<String, Object> response = new HashMap<>();
        response.put("driver", driver);
        response.put("probability", probability);
        if (probability == -1.0) {
            response.put("error", "Пилот не найден");
        }
        return response;
    }

    @GetMapping("/last-race")
    public Map<String, Object> getLastRace() {
        try {
            List<Map<String, Object>> results = openF1Service.getLastRaceResults();
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("results", results);
            return response;
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("error", e.getMessage());
            return response;
        }
    }

    @PostMapping("/update")
    public Map<String, Object> triggerUpdate() {
        Map<String, Object> response = new HashMap<>();
        try {
            openF1Service.updateStandings();
            response.put("status", "success");
            response.put("message", "✅ База данных обновлена, кэш очищен");
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", "❌ Ошибка: " + e.getMessage());
        }
        return response;
    }
}