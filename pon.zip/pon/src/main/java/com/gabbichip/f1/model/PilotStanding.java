package com.gabbichip.f1.model;

public class PilotStanding {
    private int id;
    private String name;
    private int points;
    private String number;
    private String team;

    public PilotStanding() {}

    public PilotStanding(int id, String name, int points, String number, String team) {
        this.id = id;
        this.name = name;
        this.points = points;
        this.number = number;
        this.team = team;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }
    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }
    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }
}