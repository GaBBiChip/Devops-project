package com.gabbichip.f1.service;

import com.gabbichip.f1.model.PilotStanding;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StandingsService {

    private final JdbcTemplate jdbcTemplate;

    public StandingsService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<PilotStanding> getAllStandings() {
        return jdbcTemplate.query(
                "SELECT name, points, number, team FROM standings ORDER BY points DESC",
                (rs, rowNum) -> new PilotStanding(
                        rs.getString("name"),
                        rs.getInt("points"),
                        rs.getString("number"),
                        rs.getString("team")
                )
        );
    }

    public double calculateProbability(String driverName) {
        List<PilotStanding> standings = getAllStandings();
        if (standings.isEmpty()) return 0.0;

        PilotStanding leader = standings.get(0);
        PilotStanding target = standings.stream()
                .filter(p -> p.getName().toLowerCase().contains(driverName.toLowerCase()))
                .findFirst()
                .orElse(null);

        if (target == null) return -1.0; // Пилот не найден

        int racesLeft = 3; // Можно сделать динамическим
        int maxRemainingPoints = racesLeft * 26;
        int pointGap = leader.getPoints() - target.getPoints();

        if (pointGap <= 0) return 100.0;
        if (pointGap <= maxRemainingPoints) {
            return (1.0 - ((double) pointGap / maxRemainingPoints)) * 100;
        }
        return 0.0;
    }
}