package com.gabbichip.f1.model;

public class PilotStanding {
    private String name;
    private int points;
    private String number;
    private String team;

    public PilotStanding() {}

    public PilotStanding(String name, int points, String number, String team) {
        this.name = name;
        this.points = points;
        this.number = number;
        this.team = team;
    }

    // Getters and setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }
    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }
    public String getTeam() { return team; }
    public void setTeam(String team) { this.team = team; }
}