package com.gabbichip.f1.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class OpenF1Service {

    public List<Map<String, Object>> getLastRaceResults() throws Exception {
        // 1) Последняя гонка
        String sessionsJson = fetch("https://api.openf1.org/v1/sessions?session_type=Race&session_key=latest");
        JsonArray sessions = JsonParser.parseString(sessionsJson).getAsJsonArray();
        if (sessions.isEmpty()) return List.of();

        JsonObject lastSession = sessions.get(0).getAsJsonObject();
        int sessionKey = lastSession.get("session_key").getAsInt();

        // meeting_name НЕТ в /sessions — используем session_name + location + country
        String location = safeString(lastSession, "location", "Unknown");
        String country = safeString(lastSession, "country_name", "");
        String raceName = location + (country.isEmpty() ? "" : ", " + country);

        // 2) Все позиции гонки (без lap_last — берём всё)
        String positionsJson = fetch("https://api.openf1.org/v1/position?session_key=" + sessionKey);
        JsonArray positions = JsonParser.parseString(positionsJson).getAsJsonArray();

        // Для каждого пилота оставляем ПОСЛЕДНЮЮ запись (финальная позиция)
        Map<Integer, Integer> finalPositions = new LinkedHashMap<>();
        for (JsonElement p : positions) {
            JsonObject pos = p.getAsJsonObject();
            if (!pos.has("driver_number") || !pos.has("position")) continue;
            int driverNumber = pos.get("driver_number").getAsInt();
            int position = pos.get("position").getAsInt();
            finalPositions.put(driverNumber, position); // перезаписываем → остаётся последняя
        }

        // 3) Справочник пилотов
        String driversJson = fetch("https://api.openf1.org/v1/drivers?session_key=" + sessionKey);
        JsonArray drivers = JsonParser.parseString(driversJson).getAsJsonArray();
        Map<Integer, JsonObject> driverMap = new HashMap<>();
        if (drivers != null) {
            for (JsonElement d : drivers) {
                JsonObject obj = d.getAsJsonObject();
                if (obj.has("driver_number")) {
                    driverMap.put(obj.get("driver_number").getAsInt(), obj);
                }
            }
        }

        // 4) Собираем результаты, сортируем по позиции
        List<Map<String, Object>> results = finalPositions.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .map(entry -> {
                    int driverNumber = entry.getKey();
                    int position = entry.getValue();
                    JsonObject driverInfo = driverMap.get(driverNumber);

                    Map<String, Object> result = new HashMap<>();
                    result.put("position", position);
                    result.put("driver", driverInfo != null
                            ? safeString(driverInfo, "full_name", "Pilot #" + driverNumber)
                            : "Pilot #" + driverNumber);
                    result.put("team", driverInfo != null
                            ? safeString(driverInfo, "team_name", "Unknown")
                            : "Unknown");
                    return result;
                })
                .collect(Collectors.toList());

        // 5) Метаданные — первым элементом (как ожидает frontend)
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("raceName", raceName);
        metadata.put("location", location);
        metadata.put("sessionKey", sessionKey);
        results.add(0, metadata);

        return results;
    }

    // Безопасное чтение строки — не упадёт, если поля нет или оно null
    private String safeString(JsonObject obj, String key, String fallback) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return fallback;
        return obj.get(key).getAsString();
    }

    private String fetch(String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(15))
                .GET().build();
        HttpResponse<String> resp = HttpClient.newHttpClient()
                .send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) {
            throw new RuntimeException("HTTP " + resp.statusCode() + " для URL: " + url);
        }
        return resp.body();
    }
}